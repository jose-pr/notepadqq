=== MESSAGES ===

JS --> C++
----------

* J_EVT_READY()
  Notify when the editor is fully loaded.
* J_EVT_CONTENT_CHANGED()
