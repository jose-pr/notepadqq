#ifndef GLOBALS_H
#define GLOBALS_H

#include <QString>

void print(QString string);
void println(QString string);
void printerr(QString string);
void printerrln(QString string);

#endif // GLOBALS_H

