# Notepadqq API Documentation

Documentation for developers of Notepadqq extensions.

Version 0.50